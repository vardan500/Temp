# AI Resource Chargeback (FinOps)

How to attribute **Azure OpenAI / AI Foundry** and **Azure AI Services** (Cognitive
Services, Document Intelligence, Speech, AI Search) cost to the business, extending the
existing FinOps tagging chargeback (`03-pillar-finops.md`).

**Primary chargeback dimensions:** `cost center` + `department`. **Join key:** the
**APIM subscription** — all consumer traffic to shared AI endpoints flows through
**Azure API Management**, every call carries the consumer's subscription key, and
gateway telemetry emits the subscription ID (`ApimSubscriptionId`) on every request.
**Secondary:** `project`.

## 1. Why AI needs more than resource tags
A resource's `cost center` tag attributes **100%** of that resource's bill to one owner.
In this environment **every AI resource is a shared multi-tenant endpoint**, consumed by
many teams and billed by **tokens / PTUs / transactions** — so no AI cost can be attributed
by resource tags alone. All AI spend is attributed by a single **usage-based split** path:

```
APIM gateway telemetry → per-consumer usage (APIM subscription) → proportional split of the resource's bill
```

Resource-level cost tags (`cost center`, `department`, …) remain required on AI resources,
but they identify the **platform team** that owns the endpoint — and receive the
**unallocated** remainder of the split — not a consuming business unit. The only
AI-adjacent cost still attributed purely by resource tags is GPU / ML compute (§9).

## 2. AI tags (see `02-tag-taxonomy.md §1a`)
There are **no AI-specific tags**. AI resources carry only the existing default tags
(`cost center`, `department`, `app`, `project`, `owner`, `env`), which identify the
platform team (see §1), not the consumer. With a single shared platform (one Foundry,
shared Content Safety, etc.), any AI-specific resource tag would hold one constant
value, so every chargeback dimension lives where it can vary — in gateway telemetry and
the consumer map: consumer = the **APIM subscription** presented on each call (§4);
use case = `workload` column of `consumer-map.csv` (§5); billing is uniformly
**pay-as-you-go**, split per model (§6). (Retired from earlier revisions: the tags
`shared service`, `ai workload`, `ai billing model`, `app id`, and the `app`-named
calling-identity invariant — see plan.md revision notes.)

**Policies (FinOps pillar):** `audit-diagnostics-on-ai` — bundled in
`initiative-finops.json` (group `ai-cost-allocation`). Consumer attribution itself is
enforced **operationally at onboarding** (no key is issued before the consumer-map row
exists, §4), not by Azure Policy — policy cannot see APIM subscriptions.

## 3. Telemetry sources
| Source | Provides | Notes |
|--------|----------|-------|
| **APIM gateway logs** → Log Analytics | Per-call consumer identity (`ApimSubscriptionId`), API/operation, and token counts via the `llm`/`azure-openai` token policies | **Primary and mandatory** — the split key comes from here |
| Azure OpenAI **diagnostic logs** → Log Analytics | Requests, token counts, model, deployment | Reconciliation + **bypass detection**: backend usage with no matching gateway traffic means someone is calling the endpoint directly |
| Azure Monitor **metrics** | `TokenTransaction`, `ProcessedPromptTokens`, `GeneratedTokens`, `ProcessedInferenceTokens` | Good for totals, no per-consumer identity |
| AI Services (Speech, Doc Intelligence, Search) diagnostics | Transaction/operation counts | Split by transactions instead of tokens |

Because the split is the **only** attribution path, an endpoint whose traffic is not
observable produces cost that cannot be allocated at all. Diagnostics coverage on the AI
resources themselves is audited by policy (`audit-diagnostics-on-ai`) from Phase 1;
gateway coverage is guaranteed structurally — consumers can only reach the endpoints
through APIM (§4).

Enable APIM + resource diagnostics (example):
```bash
# APIM gateway logs (the split input)
az monitor diagnostic-settings create \
  --name ai-chargeback-gateway \
  --resource "<apimResourceId>" \
  --workspace "<logAnalyticsWorkspaceId>" \
  --logs '[{"category":"GatewayLogs","enabled":true},{"categoryGroup":"allLogs","enabled":true}]'

# AI resource logs (reconciliation / bypass detection)
az monitor diagnostic-settings create \
  --name ai-chargeback \
  --resource "<aiResourceId>" \
  --workspace "<logAnalyticsWorkspaceId>" \
  --logs '[{"category":"RequestResponse","enabled":true},{"category":"Audit","enabled":true}]' \
  --metrics '[{"category":"AllMetrics","enabled":true}]'
```

## 4. Consumer identity: APIM subscription keys
The split needs a reliable **consumer key** per call. That key is the **APIM
subscription**: APIM fronts every shared AI endpoint as the AI gateway, each consuming
application is issued its **own APIM subscription** (key pair) scoped to the AI
product/APIs, and the gateway stamps the immutable subscription ID into telemetry on
every call. Since every resource is shared, per-call identity is a **hard
prerequisite** — there is no dedicated-resource fallback.

The process:

1. **Front the endpoints.** All shared AI resources sit behind APIM; consumers receive
   the **gateway URL + a subscription key**, never the backend resource's own endpoint
   or keys. APIM authenticates to the backends with its **own managed identity**.
2. **Block the side door.** Disable key-based/local auth on the AI resources (or
   network-restrict them so only APIM can reach them). The split can only see traffic
   that crosses the gateway, so direct backend access must be impossible — bypass
   attempts surface as backend-log usage with no matching gateway traffic (§3).
3. **Onboard per consumer.** Creating a consumer means, in one PR, (a) creating the
   APIM subscription for the application and (b) adding its subscription ID as a row in
   `consumer-map.csv` — **before** the key is handed over. A key issued without a map
   row lands in the platform's unallocated bucket (§5) and is tracked as a KPI (a
   nonzero bucket usually means a subscription was issued outside the onboarding PR).
4. **Rotate freely.** Subscription keys have primary/secondary pairs; rotating a key
   changes nothing in telemetry or the map — the subscription ID is stable. An
   application may hold **multiple subscriptions** (per env, per client) if needed;
   each is simply another map row pointing at the same cost dimensions.

The APIM subscription ID is the single join key used everywhere (gateway telemetry +
mapping table). No naming convention is load-bearing: the join uses the ID APIM itself
emits, so a misnamed subscription cannot mis-attribute cost — only a **missing map row**
can leave it unallocated.

## 5. Consumer → allocation mapping
Maintain `ai-chargeback/consumer-map.csv` (version-controlled, PR-reviewed), keyed by
`apim subscription` (the subscription's immutable ID, as emitted in
`ApimSubscriptionId`):
```
apim subscription,cost center,department,project,workload
member-chatbot,CC-4100,DigitalBanking,DAO,member-chatbot
loan-docs,CC-5200,Lending,AKC,doc-intelligence-loans
fraud-copilot,CC-3300,RiskFraud,Consortium,fraud-copilot
```
The `workload` column is the **use-case rollup** (formerly the `ai workload` resource
tag): with one shared platform serving every use case, the use-case dimension can only
come from per-consumer data. Use-case showback = split output grouped by `workload`.
Any subscription ID seen in telemetry but **absent** from the map → **unallocated**
bucket (platform cost center — the `cost center` tag on the resource itself), tracked as
a KPI until mapped. With all AI resources shared, this map is the **sole source** of AI
consumer chargeback — treat changes to it with the same rigor as a policy change (PR
review by the platform + FinOps owners).

## 6. Split formula (paygo, per model)
All billing is **pay-as-you-go**, and token prices differ per model — raw token totals
would make consumers of cheap models subsidize consumers of expensive ones. So the split
runs **per model, then sums**. For shared resource `R`, model `m`, period `P`:

```
consumer_share(c, m) = tokens(c, m) / total_tokens(R, m, P)
consumer_cost(c)     = Σ over m of  consumer_share(c, m) × actual_cost(R, m, P)
```

- **`actual_cost(R, m, P)` — read, don't estimate:** Azure OpenAI paygo bills **per-model
  meter lines**, so each model's actual cost comes straight from the Cost Management
  usage detail / export filtered to the resource.
- **Fallback (no meter-level detail):** maintain a version-controlled model price table
  (governed like `consumer-map.csv`), compute each consumer's estimated dollars from list
  prices, use those as split weights, and scale so the total reconciles to the actual.
- **Prompt vs completion:** completion tokens are typically several times more expensive
  than prompt tokens. Where consumers differ sharply in shape (e.g., prompt-heavy RAG vs
  generation-heavy drafting), weight the two token types by their prices instead of using
  the raw `prompt + completion` sum.
- **AI Services (transactions):** `usage` = transaction/operation counts per APIM
  subscription (Content Safety, Document Intelligence, Speech, Search), split per meter
  the same way.

Always **reconcile** the sum of `consumer_cost` back to Cost Management — the delta is
the unallocated bucket.

## 7. KQL (in `ai-chargeback/queries/`)
Tokens per consumer **and model** (the model dimension is required for the per-model
split in §6; the consumer key is `ApimSubscriptionId` from the gateway logs):
```kusto
ApiManagementGatewayLlmLog                       // shape to your APIM diagnostic schema
| where TimeGenerated between (startofmonth(now()) .. now())
| join kind=inner (
    ApiManagementGatewayLogs
    | project CorrelationId, apimSubscription = tostring(ApimSubscriptionId)
  ) on CorrelationId
| extend model = tostring(DeploymentName)
| summarize prompt=sum(PromptTokens), completion=sum(CompletionTokens) by apimSubscription, model
| extend totalTokens = prompt + completion
| order by totalTokens desc
```
See the folder for `transactions-per-consumer`, `unallocated-usage`, and
`monthly-split-summary` (implements the per-model split) queries.

## 8. Showback → Chargeback phasing
| Phase | Goal | Enforcement |
|-------|------|-------------|
| **1 — Instrument & Audit** | APIM in front of every shared AI endpoint; direct backend access disabled; per-consumer subscriptions issued via the onboarding PR (§4); diagnostics on every AI resource; publish **showback** per consumer; build map | FinOps policies `effect=Audit`, `diagnosticsEffect=AuditIfNotExists` |
| **2 — Attribute** | Monthly split; reconcile unallocated; gateway coverage ≥95% of backend usage and rising toward ~100% (the split is the only attribution path); validate vs Cost Management | Policies still Audit; remediate diagnostics & bypass traffic |
| **3 — Chargeback + Deny** | Post allocations to GL; formal chargeback | Pillar value-integrity policies → `Deny` per `06`; AI attribution enforcement stays **operational** (subscription-before-map-row onboarding + diagnostics audit) — there is no AI tag left to Deny |

Cadence 30–60 days per phase, gated on coverage/reconciliation accuracy (mirrors
`06-governance-policy-plan.md`).

## 9. Special cases
- **GPU / ML compute (VMs, AKS GPU nodes, ML compute):** out of primary scope but attribute
  via existing cost tags on the compute resource; note as a future extension.
- **Data sensitivity:** keep split dimensions to non-content metadata (ids, counts, model,
  tokens) — never prompt/response content. Align AI resources with SecOps
  `data classification`.
- **Unmapped/bypass usage:** platform `cost center` bucket + KPI; drive to zero.
- **PTU / commitment later:** if a reservation is ever adopted for a stable heavy
  workload, reintroduce the `ai billing model` tag and an amortization method (usage
  share vs provisioned share) — see plan.md revision history.

## 10. Worked example (per-model split)
Shared Azure OpenAI endpoint, actual monthly cost **$10,000** — Cost Management meters:
**gpt-4o $8,000**, **gpt-4o-mini $2,000**. Split each model's cost by that model's tokens:

| Model (actual cost) | apim subscription | tokens | share | charge |
|---------------------|-------------------|--------|-------|--------|
| gpt-4o ($8,000) | member-chatbot | 6,000,000 | 60% | $4,800 |
| | fraud-copilot | 3,000,000 | 30% | $2,400 |
| | (unmapped) | 1,000,000 | 10% | $800 |
| gpt-4o-mini ($2,000) | member-chatbot | 5,000,000 | 25% | $500 |
| | loan-docs | 15,000,000 | 75% | $1,500 |

Summed per consumer:
| apim subscription | charge | allocation |
|-------------------|--------|------------|
| member-chatbot | $5,300 | CC-4100 / DigitalBanking (`member-chatbot`) |
| fraud-copilot | $2,400 | CC-3300 / RiskFraud (`fraud-copilot`) |
| loan-docs | $1,500 | CC-5200 / Lending (`doc-intelligence-loans`) |
| (unmapped) | $800 | platform bucket (KPI — a subscription issued without a map row, see §4) |
| **Total** | **$10,000** | ✓ reconciles |

Note why per-model matters: `member-chatbot` generated 37% of all tokens (11M of 30M)
but owes 53% of the cost, because most of its tokens hit the expensive model. A raw
token split would have under-charged it and over-charged `loan-docs`.

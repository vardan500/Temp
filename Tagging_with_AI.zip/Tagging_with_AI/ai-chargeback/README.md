# AI Chargeback — telemetry & allocation assets

Assets that power the **usage-based split** — the sole attribution path for AI spend,
since every AI resource is a shared multi-tenant endpoint fronted by **Azure API
Management**. See `../docs/08-ai-chargeback.md` for the full method.

## Files
- `consumer-map.csv` — `apim subscription → cost center, department, project, workload`.
  The version-controlled join between gateway telemetry and the chargeback dimensions,
  keyed by the **APIM subscription ID**: every consumer call carries its subscription
  key, so the gateway logs emit the consumer directly (`ApimSubscriptionId`). The
  `workload` column is the use-case rollup (there are no per-use-case resources to tag
  on a single shared platform). PR-reviewed; any subscription ID in telemetry but not
  here → unallocated (platform bucket) KPI — usually a key issued outside the
  onboarding PR.
- `queries/tokens-per-consumer.kql` — token usage per APIM subscription and model
  (Azure OpenAI).
- `queries/transactions-per-consumer.kql` — transaction counts per APIM subscription
  (AI Services).
- `queries/unallocated-usage.kql` — usage whose APIM subscription is missing/unmapped.
- `queries/monthly-split-summary.kql` — per-consumer charge, split per model then
  summed (model prices differ; each model's Cost Management meter cost is split by that
  model's tokens).

## Usage
1. Enable diagnostics on the APIM gateway and on shared AI resources → Log Analytics
   (see `docs/08 §3`).
2. Adjust the table/column names in each query to match your APIM diagnostic schema.
3. Run monthly; join results to `consumer-map.csv`; apply the split formula in `docs/08 §6`;
   reconcile the total back to Cost Management.
